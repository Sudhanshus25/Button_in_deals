// This script handles the Bitrix24 placement integration
document.addEventListener('DOMContentLoaded', function() {
    // Check if we're running inside Bitrix24 with placement data
    if (window === window.top) {
        // We're not in an iframe, show installation instructions
        document.getElementById('app-content').style.display = 'block';
        document.getElementById('placement-handler').style.display = 'none';
    } else {
        // We're in an iframe (likely Bitrix24 placement)
        document.getElementById('app-content').style.display = 'none';
        document.getElementById('placement-handler').style.display = 'block';
        
        // Initialize the Bitrix24 app
        initBitrixApp();
    }
});

// Initialize the Bitrix24 app
function initBitrixApp() {
    BX.ready(function() {
        // Listen for placement registration
        BX.addCustomEvent(window, "onPlacementRegister", function(placementData) {
            if (placementData.placement === 'CRM_DEAL_DETAIL_TOOLBAR') {
                handlePlacement(placementData);
            }
        });
        
        // Simulate receiving placement data for demonstration
        // In a real implementation, this would come from Bitrix24
        setTimeout(() => {
            const simulatedPlacementData = {
                placement: 'CRM_DEAL_DETAIL_TOOLBAR',
                options: {
                    ID: '6591'
                }
            };
            handlePlacement(simulatedPlacementData);
        }, 1000);
    });
}

// Handle the placement registration
function handlePlacement(placementData) {
    console.log("Placement data received:", placementData);
    
    // Extract deal ID from placement options
    const dealId = placementData.options.ID;
    document.getElementById('deal-id').textContent = dealId;
    
    // Set up button event listeners
    document.getElementById('fetch-deal-info').addEventListener('click', function() {
        fetchDealDetails(dealId);
    });
    
    document.getElementById('perform-action').addEventListener('click', function() {
        performCustomAction(dealId);
    });
}

// Function to fetch deal details using Bitrix24 REST API
function fetchDealDetails(dealId) {
    // In a real implementation, you would use the Bitrix24 REST API
    // This is a simulation for demonstration purposes
    
    const dealInfoDiv = document.getElementById('deal-info');
    dealInfoDiv.innerHTML = '<p>Fetching deal information...</p>';
    
    // Simulate API call delay
    setTimeout(() => {
        // Simulated deal data
        const dealData = {
            ID: dealId,
            TITLE: `Deal #${dealId}`,
            STAGE_ID: "C1:NEW",
            PROBABILITY: 50,
            OPPORTUNITY: 10000,
            CURRENCY_ID: "USD",
            ASSIGNED_BY_ID: "1",
            CREATED_BY_ID: "1",
            DATE_CREATE: new Date().toISOString(),
            DATE_MODIFY: new Date().toISOString()
        };
        
        // Display the deal information
        let html = '<h4>Deal Information</h4>';
        html += '<ul>';
        for (const [key, value] of Object.entries(dealData)) {
            html += `<li><strong>${key}:</strong> ${value}</li>`;
        }
        html += '</ul>';
        
        dealInfoDiv.innerHTML = html;
    }, 1000);
}

// Function to perform a custom action on the deal
function performCustomAction(dealId) {
    // In a real implementation, this would perform your custom action
    // This is a simulation for demonstration purposes
    
    const dealInfoDiv = document.getElementById('deal-info');
    dealInfoDiv.innerHTML = '<p>Performing custom action...</p>';
    
    // Simulate action delay
    setTimeout(() => {
        dealInfoDiv.innerHTML = `
            <div style="color: green;">
                <h4>Action Completed Successfully!</h4>
                <p>Custom action performed on Deal #${dealId}</p>
                <p>Timestamp: ${new Date().toLocaleString()}</p>
            </div>
        `;
    }, 1500);
}

// Handle the POST data that Bitrix24 sends to our placement
// In a real implementation, this would be processed server-side
function handlePlacementData(data) {
    console.log("Received placement data:", data);
    
    // Extract deal ID from placement options
    let placementOptions = {};
    try {
        placementOptions = JSON.parse(data.PLACEMENT_OPTIONS || '{}');
    } catch (e) {
        console.error("Error parsing PLACEMENT_OPTIONS", e);
    }
    
    const dealId = placementOptions.ID;
    console.log("Deal ID:", dealId);
    
    // Update the UI with the deal ID
    document.getElementById('deal-id').textContent = dealId || 'Not available';
    
    // Now we can use this deal ID to perform actions on the specific deal
    if (dealId) {
        // Set up button event listeners
        document.getElementById('fetch-deal-info').addEventListener('click', function() {
            fetchDealDetails(dealId);
        });
        
        document.getElementById('perform-action').addEventListener('click', function() {
            performCustomAction(dealId);
        });
    }
}

// For demonstration purposes, let's simulate receiving data from Bitrix24
// In a real implementation, this data would come from Bitrix24 via POST request
const simulatedData = {
    DOMAIN: 'instloo.bitrix24.com',
    PROTOCOL: '1',
    LANG: 'en',
    APP_SID: '0d43bf11edd7e3c050ea8b0577eb6a87',
    AUTH_ID: '18d3a06600631fcd00005a4b00000001f0f1077b7ce52f79713d82c4bc9960bcf4b598',
    AUTH_EXPIRES: '3600',
    REFRESH_ID: '0852c86600631fcd00005a4b00000001f0f107ce505dcd9306e0eb55ad77df1d2b2f16',
    member_id: 'da45a03b265edd8787f8a258d793cc5d',
    status: 'L',
    PLACEMENT: 'CRM_DEAL_DETAIL_TOOLBAR',
    PLACEMENT_OPTIONS: '{"ID":"6591"}'
};

// Simulate handling the placement data
// In a real implementation, this would be triggered by Bitrix24
console.log("Simulating Bitrix24 placement data handling:");
handlePlacementData(simulatedData);